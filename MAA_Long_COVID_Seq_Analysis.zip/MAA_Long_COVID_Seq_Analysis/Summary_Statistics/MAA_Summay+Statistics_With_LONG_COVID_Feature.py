import pandas as pd
import numpy as np

# Long COvid and Sequecne match
df = pd.read_csv("MAA_FaxSeqDownload_1_23_2023_With_3199_LONG_COVID_Feature.csv",encoding= 'unicode_escape')

df.shape

df.info()
#df['Age'] = df['Age'].astype(float)


df["Patient Zip"].unique()
df["Gender"].value_counts()
print(df.describe(include='all'))

df['Age'].describe(include=all)
df.groupby(['Long_COVID'])['Age'].describe(include=all)

df['Gender'].describe(include=all)
df.groupby(['Gender'])['Gender'].describe(include=all)
df.groupby(['Long_COVID','Gender'])['Gender'].describe(include=all)


df['Race'].describe(include=all)
dd=df.groupby(['Race'])['Race'].describe(include=all)
dd.to_csv('tt.csv')  #calcualte%
ddd=df.groupby(['Long_COVID','Race' ])['Race'].describe(include=all)
ddd.to_csv('tt1.csv')  #calcualte%

dd1=df.groupby(['Ethnicity'])['Ethnicity'].describe(include=all)
dd1.to_csv('tt2.csv')  # calcualte %
ddd1=df.groupby(['Long_COVID','Ethnicity' ])['Ethnicity'].describe(include=all)
ddd1.to_csv('tt3.csv')  # calcualte %

df.groupby(['Vaccinated'])['Vaccinated'].describe(include=all)
df.groupby(['Long_COVID','Vaccinated' ])['Vaccinated'].describe(include=all)
#############################################
### Mean test for Age group by Long COVID

from scipy.stats import ttest_ind
import seaborn as sns
import matplotlib.pyplot as plt


df = pd.read_csv("MAA_FaxSeqDownload_1_23_2023_With_3199_LONG_COVID_Feature.csv",encoding= 'unicode_escape')

group1 = df[df['Long_COVID']==1]
group2 = df[df['Long_COVID']==0]

sns.set(style="darkgrid")
# creating a figure composed of two matplotlib.Axes objects (ax_box and ax_hist)
f, (ax_box, ax_hist) = plt.subplots(2, sharex=True, gridspec_kw={"height_ratios": (.15, .85)})
 
# assigning a graph to each ax
#sns.boxplot(x=df["Age"])
#sns.boxplot(df["Age"], ax=ax_box)
sns.histplot(data=df, x="Age", ax=ax_hist)
sns.histplot(data=group1, x="Age", ax=ax_hist)
sns.histplot(data=group2, x="Age", ax=ax_hist)
 
# Remove x axis name for the boxplot
ax_box.set(xlabel='')
plt.show()


sns.boxplot(data=df, x="Age", y="Long_COVID")

sns.boxplot(group1["Age"],group2["Age"], orient="h")
sns.histplot(data=group1, x="Age", ax=ax_hist)

plt.show()


#perform independent two sample t-test
#ttest_ind(group1['Age'], group2['Age'])

ttest_ind(group1.dropna()['Age'], group2.dropna()['Age']) #CAT01209 Age is messing 

 #Ttest_indResult(statistic=3.7009403494801987, pvalue=0.0002330344808131744)
## Histogram and boxplot of age groupby Long COVID
#Welch’s t-Test in Pandas
#perform Welch's t-test ( No assumtion that the pubulation variance are equale.
ttest_ind(group1.dropna()['Age'], group2.dropna()['Age'],equal_var=False)







######################## Chisquare  test####
import scipy.stats as stats
compare = pd.crosstab(df['Long_COVID'],df['Gender'])
# are these variables independent?
chi2, p, dof, ex = stats.chi2_contingency(compare)

print(f'Chi_square value {chi2}\n\np value {p}\n\ndegrees of freedom {dof}\n\n expected {ex}')
#Chi_square value 9.707540700757445

#p value 0.0018351343246990799; degrees of freedom 1; 
#expected [[928.17286652 716.82713348];  [876.82713348 677.17286652]]

#########Race
compare1 = pd.crosstab(df['Long_COVID'],df['Race'])
# are these variables independent?
chi2, p, dof, ex = stats.chi2_contingency(compare1)

print(f'Chi_square value {chi2}\n\np value {p}\n\ndegrees of freedom {dof}\n\n expected {ex}')
#Chi_square value 57.82806500042461; p value 1.2409513413009472e-09; degrees of freedom 8
# expected [[  7.71334792  19.5404814    1.02844639 584.15754923   3.59956236
 #  24.68271335   3.59956236  40.10940919 960.56892779]
 #[  7.28665208  18.4595186    0.97155361 551.84245077   3.40043764
 #  23.31728665   3.40043764  37.89059081 907.43107221]]
 

#########Ethnicity
compare2 = pd.crosstab(df['Long_COVID'],df['Ethnicity'])
# are these variables independent?
chi2, p, dof, ex = stats.chi2_contingency(compare2)

print(f'Chi_square value {chi2}\n\np value {p}\n\ndegrees of freedom {dof}\n\n expected {ex}')

#Chi_square value 85.49596063426854

#p value 1.6757196787855156e-11

#degrees of freedom 16

 #expected [[2.19573304e+02 3.59956236e+00 4.62800875e+00 4.61772429e+02
  #5.14223195e-01 5.14223195e-01 4.78227571e+01 3.80525164e+01
  #4.62800875e+00 5.14223195e-01 2.57111597e+00 7.88304158e+02
  #1.69693654e+01 4.11378556e+00 4.93654267e+01 1.54266958e+00
  #5.14223195e-01]
 #[2.07426696e+02 3.40043764e+00 4.37199125e+00 4.36227571e+02
  #4.85776805e-01 4.85776805e-01 4.51772429e+01 3.59474836e+01
  #4.37199125e+00 4.85776805e-01 2.42888403e+00 7.44695842e+02
  #1.60306346e+01 3.88621444e+00 4.66345733e+01 1.45733042e+00
  #4.85776805e-01]]
##############################


#########Ethnicity
compare3 = pd.crosstab(df['Long_COVID'],df['Vaccinated'])
# are these variables independent?
chi2, p, dof, ex = stats.chi2_contingency(compare3)

print(f'Chi_square value {chi2}\n\np value {p}\n\ndegrees of freedom {dof}\n\n expected {ex}')

#Chi_square value 36.86654918602196 #p value 1.2649776941947592e-09; degrees of freedom 1

 #expected [[1055.18599562  589.81400438]
 #[ 996.81400438  557.18599562]]

