### Mean test for Age group by Long COVID
import pandas as pd
import numpy as np

from scipy.stats import ttest_ind
import seaborn as sns
import matplotlib.pyplot as plt


df = pd.read_csv("MAA_FaxSeqDownload_1_23_2023_With_3199_LONG_COVID_Feature.csv",encoding= 'unicode_escape')

group1 = df[df['Long_COVID']==1]
group2 = df[df['Long_COVID']==0]

sns.set(style="darkgrid")
sns.histplot(data=df, x="Age",color='royalblue')
sns.histplot(data=group2, x="Age", color='teal' )
sns.histplot(data=group1, x="Age",  color='tan' )
plt.legend(['All patients', 
           ' Not long COVID patients',  'Long COVID patients' ])
plt.show()

sns.boxplot(x= df['Long_COVID'], y=df["Age"])
#plt.legend(['Not long COVID patients',  'Long COVID patients' ],loc='upper center')

# Box plot with jitter

sns.boxplot(x= df['Long_COVID'], y=df["Age"])
sns.stripplot(x= df['Long_COVID'], y=df["Age"], color="black", jitter=0.2, size=2.5)
plt.show()
############### Violin plot
# plot violin chart
sns.violinplot( x= df['Long_COVID'], y=df["Age"], data=df)

# add title
plt.title("Violin plot", loc="left")

# show the graph
plt.show()



# creating a figure composed of two matplotlib.Axes objects (ax_box and ax_hist)
f, (ax_box, ax_hist) = plt.subplots(2, sharex=True, gridspec_kw={"height_ratios": (.15, .85)})
 
# assigning a graph to each ax
#sns.boxplot(x=df["Age"])
#sns.boxplot(df["Age"], ax=ax_box)
sns.histplot(data=df, x="Age", ax=ax_hist)
sns.histplot(data=group1, x="Age", ax=ax_hist)
sns.histplot(data=group2, x="Age", ax=ax_hist)
 
# Remove x axis name for the boxplot
ax_box.set(xlabel='')
plt.show()
