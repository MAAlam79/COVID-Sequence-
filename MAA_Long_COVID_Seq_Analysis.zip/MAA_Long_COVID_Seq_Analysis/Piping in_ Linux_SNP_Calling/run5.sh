#! /bin/bash
for f in *.fasta; do
    b=`basename $f .fasta`
    #echo Processing ligand $b
    /home/2067132/Programs/bwa-0.7.17/bwa mem -t 8 Index/NC_045512.fasta $f > out_$f.sam
    /home/2067132/Programs/samtools/bin/samtools view -b out_$f.sam > out_$f.bam
    /home/2067132/Programs/samtools/bin/samtools sort -o out_$f.sorted.bam out_$f.bam
    /home/2067132/Programs/samtools/bin/samtools index out_$f.sorted.bam
    /home/2067132/Programs/samtools/bin/samtools flagstat out_$f.sorted.bam
    /home/2067132/Programs/bcftools-1.9/bcftools mpileup -f Index/NC_045512.fasta out_$f.sorted.bam | /home/2067132/Programs/bcftools-1.9/bcftools call -mv -Ob -o out_$f.bcf
    /home/2067132/Programs/bcftools-1.9/bcftools view out_$f.bcf > outSNP_$f.vcf
done
