import pandas as pd
import numpy as np

df1 = pd.read_csv("Pass_WithAccetion_number_3519.csv",encoding= 'unicode_escape')
df2 = pd.read_csv("id_map_update_PAT_ID_&_MRN.csv",encoding= 'unicode_escape')





#df['MRN'] = df['MRN'].where(df['MRN'].isin(df['PAT_MRN_ID2']))
#df1['PATIEN_ID']  = df1.iloc[:, 0].where(df1.iloc[:, 0].isin(df2.iloc[:, 0]))

df2['AA']  = df2.iloc[:, 0].where(df2.iloc[:, 0].isin(df1.iloc[:, 0]))


#print(df1)
df3=df2.dropna()
print(df3)
#df3.to_csv('MAA_ID_map_Seq_accession number_and_Long_COVID_MRN.csv')
df3.to_csv('tt3.csv')
##############
###  From FoxSeqDownload_1_23_2023 usnder condition: Pass with accesestion number with MRN (Ochsner Patients only) 
df4 = pd.read_csv("MAA_FoxSeqDownload_1_23_2023_withNCBI.csv",encoding= 'unicode_escape')
df5 = pd.read_csv("MAA_map_id_Pass_WithAccetion_Number_MRN(OCH)_3199.csv",encoding= 'unicode_escape')


df4['AA']  = df4.iloc[:, 0].where(df4.iloc[:, 0].isin(df5.iloc[:, 0]))


print(df4)
#df6=df4.dropna()
df6=df4.dropna(subset=['AA'])

df6.to_csv('tt3.csv')
# remove col.1 and final colum ( 'AA') and add MRN colum. The file name should be 
#MAA_FaxSeqDownload_1_23_2023_With_3199_PAT_ID_&_Accession_Number_MRN(OCH"
