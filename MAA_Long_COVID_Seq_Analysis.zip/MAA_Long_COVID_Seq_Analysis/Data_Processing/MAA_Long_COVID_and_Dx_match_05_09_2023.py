import pandas as pd
import numpy as np

df = pd.read_csv("updated_dx_05022023.csv",encoding= 'unicode_escape')
df1 = pd.read_csv("MAA_unique_ICD10CM_for_conditions.csv",encoding= 'unicode_escape')# From FINAL_extraction_code_10-11-2022,sheet 2
df2 = pd.read_csv("MAA_FaxSeqDownload_1_23_2023_With_3199_PAT_ID_&_Accession_Number_MRN(OCH).csv",encoding= 'unicode_escape')


#AA=df.duplicated(['DIAGNOSIS_CODE','dxcode'])
#df['DIAGNOSIS_CODE'] = df['DIAGNOSIS_CODE'].where(df['DIAGNOSIS_CODE'].isin(df1.iloc[:, 0]))
df['PAT_MRN_ID']=df.iloc[:, 0].where(df.iloc[:, 0].isin(df2.iloc[:, 1]))

df3=df.dropna(subset=['PAT_MRN_ID'])
print(df3)


df3['DIAGNOSIS_CODE']=df3.iloc[:, 5].where(df3.iloc[:, 5].isin(df1.iloc[:, 3]))
df4=df3.dropna(subset=['DIAGNOSIS_CODE']) # only diagonsis match


df5= df4.loc[(df4['EARLIEST']>0)& (df4['LATEST']>90)]

UMRN=pd.unique(df5['PAT_MRN_ID'])

UMRN=df5['PAT_MRN_ID'].unique()


print(UMRN)
UMRN.to_csv('tt.csv')

#print(df5)
df5.to_csv('MAA_All_Long_COVID_PAT_&_Dianosis_With_Follow_Up.csv')# LongCOvid Diagonis file

# Long COvid and Sequecne match
df = pd.read_csv("MAA_All_Long_COVID_PAT_&_Dianosis_With_Follow_Up.csv",encoding= 'unicode_escape')# ater saving we need to delate first col.
df2 = pd.read_csv("MAA_FaxSeqDownload_1_23_2023_With_3199_PAT_ID_&_Accession_Number_MRN(OCH).csv",encoding= 'unicode_escape')

df2['MRN']=df2.iloc[:, 1].where(df2.iloc[:, 1].isin(df.iloc[:, 0]))


df6=df2.dropna(subset=['MRN'])
print(df6)
df6.to_csv('MAA_FaxSeqDownload_1_23_2023_With_1554_Long_COvid_PAT_ID_&_Accession_Number_MRN(OCH).csv')
# Four MRN are twices ( MRN 588685, 752048,1010405, and 6346510). Eacn has twice PAT_ID, i have deleted one of them. So in toal 1550 uniqueq Long COVID PAT_ID

