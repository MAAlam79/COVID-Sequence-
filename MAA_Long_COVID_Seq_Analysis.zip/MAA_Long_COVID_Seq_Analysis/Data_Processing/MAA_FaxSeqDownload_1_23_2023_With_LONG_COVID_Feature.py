import pandas as pd
import numpy as np

# Long COvid and Sequecne match
df = pd.read_csv("MAA_All_Long_COVID_PAT_&_Dianosis_With_Follow_Up.csv",encoding= 'unicode_escape')# ater saving we need to delate first col.
df2 = pd.read_csv("MAA_FaxSeqDownload_1_23_2023_With_3199_PAT_ID_&_Accession_Number_MRN(OCH).csv",encoding= 'unicode_escape')

df2['Long_COVID']=df2.iloc[:, 1].where(df2.iloc[:, 1].isin(df.iloc[:, 0]))
#df6=df2.dropna(subset=['MRN'])
#print(df6)
print(df2)
df2["Long_COVID"] = df2["Long_COVID"].fillna(0)
df2['Long_COVID'].values[df2['Long_COVID']>0]= 1

df2.to_csv('MAA_FaxSeqDownload_1_23_2023_With_3199_LONG_COVID_Feature.csv')
# 0 means No Long covid and means Long COVID
