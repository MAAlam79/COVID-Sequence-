from pip._internal import main
import seaborn as sns
import os
import itertools
from itertools import zip_longest
from Bio import SeqIO
from Bio.Seq import Seq
import Bio, pandas
import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import pandas as pd
import numpy as np
import seaborn as ses
import matplotlib.pyplot as plt
cwd = os.getcwd()
print('Current Working Directory is:', cwd)
from Bio import SeqIO
from Bio import Entrez
Entrez.email="Your.Name.Here@example.org"

for record in SeqIO.parse("Seq_458.fasta", "fasta"):
    species = record.id.split('_')[0]
    with open(f"{species}.fasta", "a") as f:
        SeqIO.write(record, f, "fasta")
