from pip._internal import main
import seaborn as sns
import os
import itertools
from itertools import zip_longest
from Bio import SeqIO
from Bio.Seq import Seq
import Bio, pandas
import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import pandas as pd
import numpy as np
import seaborn as ses
import matplotlib.pyplot as plt
cwd = os.getcwd()
print('Current Working Directory is:', cwd)
from Bio import SeqIO
from Bio import Entrez
Entrez.email="Your.Name.Here@example.org"


# Fetch sequence
search = Entrez.esearch(db='nucleotide', term='Tobacco mosaic virus[Orgn] AND replicase')
read = Entrez.read(search)
idlist = read["IdList"]

def singleEntry(singleID):   #the singleID is the accession number
    handle = Entrez.efetch(db='nucleotide',id=singleID, rettype = 'fasta', retmode= 'text')
    f = open('%s.fasta' % singleID, 'w')
    f.write(handle.read())
    handle.close()
    f.close()
#for i in  [0,1,2,3]:
 #   singleEntry(idlist[i])

############calling assection number of Seq-458
import csv
#Alldata = open("MAA_FaxSeqDownload_1_23_2023_With_3199_PAT_ID_&_Accession_Number_MRN(OCH).csv", "r")
#file = Alldata['Genbank Accession']
#data= list(file)
import csv
import pandas as pd
Alldata = pd.read_csv("MAA_FaxSeqDownload_1_23_2023_With_3199_PAT_ID_&_Accession_Number_MRN(OCH).csv",encoding= 'unicode_escape')

file = Alldata['Genbank Accession Number']
data= list(file)
for i,s in enumerate(data):
     data[i] = s.strip()

lst = list(range(0,3199))
print(lst)    
for l in lst:
    singleEntry(data[l])
