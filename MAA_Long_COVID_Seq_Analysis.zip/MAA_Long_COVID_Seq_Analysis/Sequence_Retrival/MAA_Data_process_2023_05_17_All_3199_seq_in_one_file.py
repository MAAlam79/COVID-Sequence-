import os
import os

DIR = 'C:/Users/2067132/OneDrive - Ochsner Health System/Desktop/Individual_Seq_3199'

oh = open('Seq_3199.fasta', 'w')
for f in os.listdir(DIR):
    fh = open(os.path.join(DIR, f))
    for line in fh:
        oh.write(line)
    fh.close()
oh.close()
