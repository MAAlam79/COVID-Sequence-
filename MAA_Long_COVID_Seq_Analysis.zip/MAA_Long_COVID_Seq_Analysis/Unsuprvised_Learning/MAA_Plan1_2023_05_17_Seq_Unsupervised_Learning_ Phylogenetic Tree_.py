from pip._internal import main
import seaborn as sns
import os
import itertools
from itertools import zip_longest
from Bio import SeqIO
from Bio.Seq import Seq
import Bio, pandas
import numpy as np
import pandas as pd
from pandas import DataFrame, Series
import pandas as pd
import numpy as np
import seaborn as ses
import matplotlib.pyplot as plt
cwd = os.getcwd()
print('Current Working Directory is:', cwd)
from Bio import SeqIO
from Bio import Entrez
sequences=[]
for seq_record in SeqIO.parse("Seq_458.fasta","fasta"):
 sequences.append(seq_record.seq)
 Entrez.email="Your.Name.Here@example.org"
search = Entrez.esearch(db='nucleotide', term='')
read = Entrez.read(search)
idlist = read["IdList"]
# Fetch sequence
search = Entrez.efetch(db='nucleotide', id=idlist[0], retmode='text', rettype='gb')
read = SeqIO.read(search, "genbank")
tmv_replicase = read.seq
print(tmv_replicase)
sizes= [len(rec) for rec in sequences]
print(sizes)
import matplotlib.pyplot as plt
plt.hist (sizes, bins=20)
plt.title(f"{len(sizes)} Sequecne\nLengths{min(sizes)} to {max(sizes)}")
plt.xlabel("Sequence lenght (bp)")
plt.ylabel("Count")
plt.show()
from Bio.SeqUtils import GC
gc_values= sorted(GC(rec) for rec in sequences)

plt.plot(gc_values)
plt.title(f"{len(sizes)} Sequecne\nGC%%{min(sizes)} to {max(sizes)}")
plt.xlabel("Genes")
plt.ylabel("GC%")
plt.show()

# Alingment
list_fasta = list(sequences)
len(list_fasta)
from Bio.Align.Applications import ClustalOmegaCommandline
from Bio import AlignIO
from Bio import SeqIO
from Bio import Seq

input_file = 'Seq_458.fasta'
records = SeqIO.parse(input_file, 'fasta')
records = list(records) # make a copy, otherwise our generator
                        # is exhausted after calculating maxlen
maxlen = max(len(record.seq) for record in records)

# pad sequences so that they all have the same length
for record in records:
    if len(record.seq) != maxlen:
        sequence = str(record.seq).ljust(maxlen, '.')
        record.seq = Seq.Seq(sequence)
assert all(len(record.seq) == maxlen for record in records)

# write to temporary file and do alignment
output_file = '{}_aligned.fasta'.format(os.path.splitext(input_file)[0])
with open(output_file, 'w') as f:
    SeqIO.write(records, f, 'fasta')
alignment = AlignIO.read(output_file, "fasta")
print(alignment)

# Distance matrix
def hamming_distance(s1, s2):
    return sum(c1 != c2 for c1, c2 in zip_longest(s1, s2))
list_fasta = list(SeqIO.parse("Seq_458.fasta", "fasta"))
n = len(list_fasta)
my_array = np.zeros((n,n))
#
for i, seq_record1 in enumerate(alignment):
    AA=str(seq_record1.seq)
    for j, seq_record2 in enumerate(alignment):
        BB=str(seq_record2.seq)
        if j >= i:
            break # Since the matrix is symmetrical we don't need to
                  # calculate everything
        distance = hamming_distance(AA, BB)  
        my_array[i, j] = distance 
        my_array[j, i] = distance 
pandas.DataFrame(my_array).to_csv('distance.inc', sep='\t')
df=pandas.DataFrame(my_array)
df_norm = (df-df.min())/(df.max()-df.min())
df_norm
np.random.seed(0)
sns.set()
sns_plot = sns.heatmap(df_norm, vmin=0, vmax=1)
#plt.show()
sns_plot.figure.savefig('Seq_458_dis_Plot.png')



#Identity model
# Identity: % of exact matches bewteen two alignedd sequence
# Similarity; % of alligned residues that share similar characteristics
from Bio import Phylo, AlignIO
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
calculator = DistanceCalculator('identity')
distMatrix = calculator.get_distance(alignment)
print(distMatrix)
#The UPGMA (unweighted pair grop method with arithmetic mean)

#Thr NJ (neighbor Joinign ) algorithm
const= DistanceTreeConstructor()
UGMATree= const.upgma(distMatrix)
NJTree= const.nj(distMatrix)
Phylo.draw(UGMATree)
Phylo.draw(NJTree)

