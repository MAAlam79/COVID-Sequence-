import numpy as np
import pandas as pd
from statsmodels.stats.proportion import proportions_ztest
#Calculate the test statistic for a z-test on 2 proportions from independent samples
 #   x1, x2: number of successes in group 1 and 2
  #  n1, n2: total number of observations in group 1 and 2
   # Returns: test statistic (z), and p-value 
def twoPro_test(x1,x2,n1, n2):
    success_cnts = np.array([x1, x2])
    total_cnts = np.array([n1, n2])
    test_stat, pval = proportions_ztest(count=success_cnts, nobs=total_cnts, alternative='two-sided')
    print('Two sided z-test: z = {:.4f}, p value = {:.4f}'.format(test_stat, pval))
    return pval


#AA = [37,36,2]
#BB =[62,74, 5]
#rows = 3
#cols = 3
#re = [[0 for _ in range(cols)] for _ in range(rows)]
#for i in range(len(AA)-1):
 #for j in range(len(BB)-1):
  #    re[i][j] = twoPro_test(AA[i],AA[i+1],BB[j],BB[j+1])
  #          #re[i][j] =AA[i]*BB[j]

twoPro_test(37,36, 62,74)
twoPro_test(37,2, 62,5)
twoPro_test(36,2, 74,5)
twoPro_test(37,12, 62,25)

# using MAA_FaxSeqDownload_1_23_2023_With_Seq3090_LONG_COVID_Feature fiel calcuate each gprop by filtering.
AA = [37,36,2,4,12,1,1,201,45,123,3,12,53,2,8,6,156,53, 456,132,28,121,9,4,3,2,13]
BB = [62,74, 5,9,25,5,7,383,82,235,9,22,106,6,14,16,236,76, 957,311,66,258,17,9,7,10,28]
rows = 27
cols = 27
re = [[0 for _ in range(cols)] for _ in range(rows)]
for i in range(len(AA)):
  for j in range(len(AA)):
     #for l in range(len(BB)):
       #for m in range(len(BB)):
        j <= len(AA);
        print(i)
        print(j)
        re[i][j] = twoPro_test(AA[i],AA[j],BB[i],BB[j])
          
             #re[i][j] =AA[i]*BB[j]
re1 =pd.DataFrame(re)           
#re1.to_csv('Pairwise_Prop-test_varient_26.csv')
#For Headmap
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv("Pairwise_Prop-test_varient_26.csv",encoding= 'unicode_escape')
y_axis_labels = ['AY100 (62, 59.68%)','AY103 (74, 48.65)','AY114 (5, 40%)','AY118 (9, 44.44%)','AY119 (25, 48%)','AY122 (5, 20%)','AY13 (7, 14%)','AY25 (383, 52.48%)','AY26 (82, 58.88%)','AY3 (235, 52.34%)','AY35 (9, 33.33%)','AY39 (22,54.55%)','AY44 (106, 50%)','AY46 (6, 33.33%)','AY47 (14,57.14%)','AY75 (16, 37.5%)','B1 (236, 66.10%)', 'B117 (76, 67.74%)','BA1 (957, 47.64%)','BA2 (311, 42.44%)','BA4 (66, 42.42%)','BA5 (258,46.90%)','BE1 (17, 52.94%)','BE3 (9, 44.44%)','BF10 (7, 42.85%)','BF26 (10, 20%)','BQ1 (28, 46.43%)']
sns.heatmap(df, cmap=sns.cubehelix_palette(as_cmap=True),yticklabels=y_axis_labels)
plt.show()
