import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv("Pairwise_Prop-test_varient_26.csv",encoding= 'unicode_escape')


y_axis_labels = ['AY100','AY103','AY114','AY118','AY119','AY122','AY13','AY25','AY26','AY3','AY35','AY39','AY44','AY46','AY47','AY75','B1','BA1','BA2','BA4','BA5','BE1','BE3','BF10','BF26','BQ1']



sns.heatmap(df, cmap=sns.cubehelix_palette(as_cmap=True),yticklabels=y_axis_labels)
plt.show()
